import UIKit

class CountryCell: UITableViewCell {

    @IBOutlet weak var imgFlag: UIImageView!
    @IBOutlet weak var labelName: UILabel!
    @IBOutlet weak var labelNativeName: UILabel!
    @IBOutlet weak var labelCapital: UILabel!
    @IBOutlet weak var labelRegion: UILabel!
    @IBOutlet weak var labelPopulation: UILabel!
    @IBOutlet weak var labelArea: UILabel!
    @IBOutlet weak var labelBorders: UILabel!
    @IBOutlet weak var latCoordinats: UILabel!
    
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }
    
    func configure(with item: CountryViewModel) {
        imgFlag.kf.setImage(with: item.flagURL, options: [.processor(SVGImgProcessor())])
        
        labelName.text = item.name
        latCoordinats.text = item.coordinatrs
    }

}
