import UIKit
import MapKit
import CoreLocation


class CountriesListViewController: UIViewController {
    
    // MARK: - IBOutlets
    
    @IBOutlet weak var tableView: UITableView!
    @IBOutlet weak var spinner: UIActivityIndicatorView!
    @IBOutlet weak var searchBar: UISearchBar!
    @IBOutlet weak var mapView: MKMapView!

    // MARK: - Private properties
    
    private var viewModel: CountriesListViewModelProtocol!
    private var dataSource: CountriesDataSource!
    private var countriesManager: CountriesManagerProtocol!
    
    let stackView = UIStackView()

    private var globalLocations: [CLLocationCoordinate2D] = []
    var locationManager: CLLocationManager?
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        setupLayout()
        configureViewModel()
        bindings()
        
        locationManager = CLLocationManager()
        locationManager?.requestAlwaysAuthorization()
        locationManager?.delegate = self
        
//        mapView.delegate = self
    }

    private func setupLayout() {
        
        
        searchBar.delegate = self
        tableView.registerNib(class: CountryCell.self)
    }
    
    private func configureViewModel() {
        countriesManager = CountriesManager()
        // DI - Dependenc Injection
        viewModel = CountriesListViewModel(with: countriesManager)
        dataSource = CountriesDataSource(with: tableView, viewModel: viewModel)
        
        viewModel.spinner = spinner
    }
    
    private func bindings() {
        viewModel.didFinishedLoading = {
            self.spinner.stopAnimating()
        }
    }
    
    @IBAction func onFetch(_ sender: Any) {
        dataSource.refresh()
        viewModel.setTitle(with: "Countries", on: navigationItem)
    }
}

extension CountriesListViewController: UISearchBarDelegate {
    func searchBar(_ searchBar: UISearchBar, textDidChange searchText: String) {
        dataSource.search(with: searchText)
    }
}


extension CountriesListViewController: CLLocationManagerDelegate {
    func locationManager(_ manager: CLLocationManager, didChangeAuthorization status: CLAuthorizationStatus) {
        switch status {
        case .authorizedAlways, .authorizedWhenInUse:
            print("მომხმარებელი დაეთანხმა ლოკაციის მოთხოვნას")
            locationManager?.startUpdatingLocation()
        case .denied, .restricted:
            print("შევატყობინოთ მომხმარებელს ალერთით რომ გადავიდეს სეთინგებში და გააქტიუროს ლოკაციაზე წვდომა ხელით")
            openSettingsAlert()
        case .notDetermined:
            print("მომხმარებელს ჯერ არ ამოირჩევია")
        default:
            break
        }
    }
    
    func locationManager(_ manager: CLLocationManager, didUpdateLocations locations: [CLLocation]) {
        guard let location = locations.last else {return}
        
        globalLocations.append(location.coordinate)
        
        print("Lat: \(location.coordinate.latitude) :: Lng: \(location.coordinate.longitude)")
        
//        manager.stopUpdatingLocation()
        
        let regionRadius: CLLocationDistance = 1_00

        let region = MKCoordinateRegion(
            center: location.coordinate,
            latitudinalMeters: regionRadius,
            longitudinalMeters: regionRadius
        )
        
        mapView.setRegion(region, animated: true)
        
        let polyline = MKPolyline(coordinates: &globalLocations, count: globalLocations.count)
        mapView.addOverlay(polyline)
    }
    
    private func openSettingsAlert() {
        let alert = UIAlertController(
            title: "ყურადღებით",
            message: "იმისთვის რომ აპლიკაციას წვდომა ქონდეს ლოკაციის სერვისთან აუცილებელია რომ გადახვიდეთ პარამეტრებში და გააქტიუროთ ხელით",
            preferredStyle: .alert
        )
        
        alert.addAction(UIAlertAction(title: "გაუქმება", style: .cancel, handler: nil))
        alert.addAction(UIAlertAction(title: "პარამეტრები", style: .default, handler: { _ in
            print("უნდა წავიდეს პარამეტრებში")
            guard let url = URL(string: UIApplication.openSettingsURLString) else { return }

            if UIApplication.shared.canOpenURL(url) {
                UIApplication.shared.open(url)
            }
        }))
        
        self.present(alert, animated: true)
    }
}


extension CountriesListViewController: MKMapViewDelegate {
    func mapView(_ mapView: MKMapView, rendererFor overlay: MKOverlay) -> MKOverlayRenderer {

        if let routePolyline = overlay as? MKPolyline {
            let renderer = MKPolylineRenderer(polyline: routePolyline)
            renderer.strokeColor = UIColor.blue.withAlphaComponent(0.9)
            renderer.lineWidth = 7
            return renderer
        }

        return MKOverlayRenderer()
    }
}
