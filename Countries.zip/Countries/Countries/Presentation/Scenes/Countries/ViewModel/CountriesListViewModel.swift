import UIKit

protocol CountriesListViewModelProtocol: AnyObject {
    func getCountriesList(completion: @escaping (([CountryViewModel]) -> Void))
    
    var didFinishedLoading: (() -> Void)? { get set }
    var spinner: UIActivityIndicatorView? { get set }
    var navigationItem: UINavigationItem? { get set }
    func setStyle(on stackVIew: UIStackView)
    func setTitle(with text: String, on navigationItem: UINavigationItem)
    
    init(with countriesManager: CountriesManagerProtocol)
}

class CountriesListViewModel: CountriesListViewModelProtocol {
    
    // MARK: - Private properties
    
    private var countriesManager: CountriesManagerProtocol!
    
    // MARK: - Outputs
    
    var didFinishedLoading: (() -> Void)?
    
    // MARK: - Internal properties
    
    var spinner: UIActivityIndicatorView?
    var navigationItem: UINavigationItem?
    
    required init(with countriesManager: CountriesManagerProtocol)  {
        self.countriesManager = countriesManager
    }
    
    func getCountriesList(completion: @escaping (([CountryViewModel]) -> Void)) {
        countriesManager.fetchCountries { countries in
            DispatchQueue.main.async {
                
                let countriesViewModels =  countries.map { CountryViewModel(country: $0) }
                
//                var viewModels = [CountryViewModel]()
//
//                for country in countries {
//                    viewModels.append(CountryViewModel(country: country))
//                }
                
                completion(countriesViewModels)
                self.spinner?.stopAnimating()
//                self.didFinishedLoading?()
            }
        }
    }
    
    func setTitle(with text: String, on navigationItem: UINavigationItem) {
        navigationItem.title = text
    }
    
    
    
    
    
    func setStyle(on stackVIew: UIStackView) {
        stackVIew.arrangedSubviews.forEach { $0.layer.cornerRadius = 10 }
    }
}
