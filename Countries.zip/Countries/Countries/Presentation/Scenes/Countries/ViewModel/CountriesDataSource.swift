import UIKit

class CountriesDataSource: NSObject, UITableViewDataSource {
    
    // MARK: - Private properties
    
    private var tableView: UITableView!
    private var viewModel: CountriesListViewModelProtocol!
    
    private var filteredCountriesList = [CountryViewModel]()
    private var countriesList = [CountryViewModel]()
    
    init(with tableView: UITableView, viewModel: CountriesListViewModelProtocol) {
        super.init()
        
        self.tableView = tableView
        self.tableView.dataSource = self
        self.tableView.delegate = self
        
        self.viewModel = viewModel
    }
    
    func refresh() {
        viewModel.getCountriesList { countries in
            self.countriesList.append(contentsOf: countries)
            self.filteredCountriesList.append(contentsOf: countries)
            self.tableView.reloadData()
        }
    }
    
    func search(with text: String) {
        filteredCountriesList.removeAll()
        
        for country in countriesList {
            if country.name.lowercased().contains(text.lowercased()) {
                filteredCountriesList.append(country)
            }
        }
        
        tableView.reloadData()
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return filteredCountriesList.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.deque(CountryCell.self, for: indexPath)
        cell.configure(with: filteredCountriesList[indexPath.row])
        return cell
    }
}


// MARK: - UITableViewDelegate

extension CountriesDataSource: UITableViewDelegate {
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        print(indexPath.row)
    }
}

