import Foundation

struct CountryViewModel {
    
    private var country: Country
    
    init(country: Country) {
        self.country = country
    }
    
    var flagURL: URL? {
        URL(string: country.flag ?? "")
    }
    
    var name: String {
        country.name ?? ""
    }
    
    
    
    
    
    var capital: String {
        country.capital ?? ""
    }
    
    
    
    var coordinatrs: String {
        ""
//        "Lat: \((country.latlng ?? [])[0]) Lng: \((country.latlng ?? [])[1])"
    }
}
