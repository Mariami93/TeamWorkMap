import Foundation

struct Country: Codable {
    let name: String?
    let capital: String?
    let flag: String?
}
